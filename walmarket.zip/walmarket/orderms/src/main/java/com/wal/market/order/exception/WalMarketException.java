package com.wal.market.order.exception;

public class WalMarketException extends Exception {

	private static final long serialVersionUID = 1L;

	public WalMarketException(String message) {
		super(message);
	}

}
